package haru.uwu.ui.clickgui.components;

import com.mojang.blaze3d.matrix.MatrixStack;
import haru.uwu.modules.api.Module;
import haru.uwu.modules.settings.api.Setting;
import haru.uwu.modules.settings.impl.*;
import haru.uwu.ui.clickgui.Panel;
import haru.uwu.ui.clickgui.components.builder.Component;
import haru.uwu.ui.clickgui.components.settings.*;
import haru.uwu.manager.Theme;
import haru.uwu.utils.client.SoundPlayer;
import haru.uwu.utils.math.MathUtility;

import haru.uwu.utils.math.Vector4i;
import haru.uwu.utils.render.Cursors;
import haru.uwu.utils.render.color.ColorUtility;
import haru.uwu.utils.render.font.Fonts;
import haru.uwu.utils.render.other.Stencil;
import haru.uwu.utils.render.engine2d.RenderUtility;
import haru.uwu.utils.text.BetterText;
import haru.uwu.utils.text.font.ClientFonts;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import lombok.Getter;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.vector.Vector4f;
import org.lwjgl.glfw.GLFW;
import ru.hogoshi.Animation;
import ru.hogoshi.util.Easings;
import haru.uwu.utils.client.KeyStorage;

import java.util.List;

@Getter
public class ModuleComponent extends Component {
    private final Vector4f ROUNDING_VECTOR = new Vector4f(5, 5, 5, 5);
    private final Vector4i BORDER_COLOR = new Vector4i(ColorUtility.rgb(45, 46, 53), ColorUtility.rgb(25, 26, 31), ColorUtility.rgb(45, 46, 53), ColorUtility.rgb(25, 26, 31));
    private final Module module;
    protected Panel panel1;
    public Animation expandAnim = new Animation();

    public Animation hoverAnim = new Animation();
    public Animation animation = new Animation();
    public Animation bindAnim = new Animation();
    public Animation noBindAnim = new Animation();

    public boolean open;

    public boolean bind;

    private double openAnimValue = 0.3, noOpenAnimValue = 0.4;

    private final ObjectArrayList<Component> components = new ObjectArrayList<>();

    public ModuleComponent(Module module) {
        this.module = module;
        for (Setting<?> setting : module.getSettings()) {
            if (setting instanceof CheckBoxSetting bool) {
                components.add(new BooleanComponent(bool));
            }
            if (setting instanceof SliderSetting slider) {
                components.add(new SliderComponent(slider));
            }
            if (setting instanceof BindSetting bind) {
                components.add(new BindComponent(bind));
            }
            if (setting instanceof ModeSetting mode) {
                components.add(new ModeComponent(mode));
            }
            if (setting instanceof ModeListSetting mode) {
                components.add(new MultiBoxComponent(mode));
            }
            if (setting instanceof StringSetting string) {
                components.add(new StringComponent(string));
            }
            if (setting instanceof ColorSetting color) {
                components.add(new ColorComponent(color));
            }


        }
        animation = animation.animate(open ? 1 : 0, 0.3);
    }

    public void drawComponents(MatrixStack stack, float mouseX, float mouseY) {
        if (animation.getValue() > 0) {
            Stencil.initStencilToWrite();
            RenderUtility.drawRoundedRect(getX() + 0.5f, getY() + 0.5f, getWidth() - 1, getHeight() - 1, ROUNDING_VECTOR, ColorUtility.rgba(23, 23, 23, (int) (255 * 0.33)));
            Stencil.readStencilBuffer(1);
            float y = getY() + 20;
            for (Component component : components) {
                if (component.isVisible()){
                    component.setX(getX());
                    component.setY(y);
                    component.setWidth(getWidth());
                    component.render(stack, mouseX, mouseY );
                    y += component.getHeight();
                }
            }
            Stencil.uninitStencilBuffer();

        }
    }

    @Override
    public void mouseRelease(float mouseX, float mouseY, int mouse) {

        for (Component component : components) {
            component.mouseRelease(mouseX, mouseY, mouse);
        }

        super.mouseRelease(mouseX, mouseY, mouse);
    }

    private boolean hovered = false;

    @Override
    public void render(MatrixStack stack, float mouseX, float mouseY) {
        int color = ColorUtility.interpolate(Theme.textColor, ColorUtility.rgb(161, 164, 177), (float) module.getAnimation().getValue());

        module.getAnimation().update();
        super.render(stack, mouseX, mouseY);

        drawOutlinedRect(mouseX, mouseY, color);
        drawText(stack, color);
        drawComponents(stack, mouseX, mouseY);

    }

    @Override
    public void mouseClick(float mouseX, float mouseY, int button) {
        if (isHovered(mouseX, mouseY, 20)) {
            if (button == 0) module.toggle();
            if (button == 1) {
                if (!module.getSettings().isEmpty()) {
                    open = !open;
                    SoundPlayer.playSound(open ? "moduleopen.wav" : "moduleclose.wav");
                    animation = animation.animate(open ? 1 : 0, open ? 0.2 : 0.1, Easings.CIRC_OUT);
                }
            }
            if (button == 2) {
                bind = !bind;
            }
        }
        if (isHovered(mouseX, mouseY)) {
            if (open) {
                for (Component component : components) {
                    if (component.isVisible()) component.mouseClick(mouseX, mouseY, button);
                }
            }
        }
        super.mouseClick(mouseX, mouseY, button);
    }

    @Override
    public void charTyped(char codePoint, int modifiers) {
        for (Component component : components) {
            if (component.isVisible()) component.charTyped(codePoint, modifiers);
        }
        super.charTyped(codePoint, modifiers);
    }

    @Override
    public void keyPressed(int key, int scanCode, int modifiers) {
        for (Component component : components) {
            if (component.isVisible()) component.keyPressed(key, scanCode, modifiers);
        }
        if (bind) {
            if (key == GLFW.GLFW_KEY_DELETE) {
                module.setBind(0);
            } else module.setBind(key);
            bind = false;
        }
        super.keyPressed(key, scanCode, modifiers);
    }


    private void drawOutlinedRect(float mouseX, float mouseY, int color) {
        int alpha = (int) (20 * module.getAnimation().getValue());
        int i = module.isEnabled() ? ColorUtility.setAlpha(Theme.mainRectColor, alpha + 55) : ColorUtility.setAlpha(ColorUtility.rgb(153,153,153), 10);

        Vector4i z = new Vector4i(
                ColorUtility.setAlpha(Theme.rectColor, 65),
                ColorUtility.setAlpha(Theme.rectColor, 65),
                ColorUtility.setAlpha(Theme.darkMainRectColor, 0),
                ColorUtility.setAlpha(Theme.darkMainRectColor, 0)
        );
        Vector4i disabledColor = new Vector4i(
                ColorUtility.setAlpha(ColorUtility.rgb(153, 153, 153), 15),
                ColorUtility.setAlpha(ColorUtility.rgb(153, 153, 153), 15),
                ColorUtility.setAlpha(ColorUtility.rgb(153, 153, 153), 0),
                ColorUtility.setAlpha(ColorUtility.rgb(153, 153, 153), 0)
        );

        RenderUtility.drawRoundedRect(
                getX() + 0.7f,
                getY() + 1,
                getWidth() - 2f,
                getHeight() - 2f,
                this.ROUNDING_VECTOR,
                module.isEnabled() ? z : disabledColor
        );


        if (MathUtility.isHovered(mouseX, mouseY, getX(), getY(), getWidth(), 20.0F)) {
            if (!this.hovered) {
                GLFW.glfwSetCursor(Minecraft.getInstance().getMainWindow().getHandle(), Cursors.HAND);
                this.hovered = true;
            }
        } else if (this.hovered) {
            GLFW.glfwSetCursor(Minecraft.getInstance().getMainWindow().getHandle(), Cursors.ARROW);
            this.hovered = false;
        }
    }

    private final BetterText gavno = new BetterText(List.of(
            "...", "...", "..."
    ), 100);

    private void drawText(MatrixStack stack, int color) {
        gavno.update();
        int i = ColorUtility.interpolate(Theme.mainRectColor, ColorUtility.rgba(153, 153, 153,15), (float) module.getAnimation().getValue());
        int i2 = module.isEnabled() ? ColorUtility.setAlpha(Theme.textColor,  255) : ColorUtility.setAlpha(ColorUtility.rgb(153,153,153), 255);

        float fontWidth = ClientFonts.msMedium[17].getWidth(module.getName());

        ClientFonts.msMedium[17].drawString(stack, !bind ? module.getName() : "",  (int)( getX() + getWidth() / 12f) , getY() + 7.5F, i2);

        if (this.components.stream().filter(Component::isVisible).count() >= 1L) {
            if (bind) {
                Fonts.montserrat.drawCenteredText(stack, (module.getBind() == 0) ? "Bind" + gavno.getOutput().toString() : KeyStorage.getReverseKey(module.getBind()), getX() + getWidth() / 2f, getY() + 7.5F, ColorUtility.rgb(153, 153, 153), 6.0F, 0.1F);
            } else {
                 RenderUtility.drawImage(new ResourceLocation("eva/images/modules/3pa.png"),getX() + getWidth() - 15, getY() + 4 + 0.0f, 11f,12f, i);
            }
        } else if (bind) {
            Fonts.montserrat.drawCenteredText(stack, (module.getBind() == 0) ? "Bind" + gavno.getOutput().toString() : KeyStorage.getReverseKey(module.getBind()), getX() + getWidth() / 2f, getY() + 7.5F, ColorUtility.rgb(153, 153, 153), 6.0F, 0.1F);
        }
    }
}