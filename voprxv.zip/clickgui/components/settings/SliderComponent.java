package haru.uwu.ui.clickgui.components.settings;

import com.mojang.blaze3d.matrix.MatrixStack;
import haru.uwu.modules.settings.impl.SliderSetting;

import haru.uwu.ui.clickgui.components.builder.Component;
import haru.uwu.utils.client.SoundPlayer;
import haru.uwu.utils.math.MathUtility;
import haru.uwu.utils.render.Cursors;

import haru.uwu.utils.render.color.ColorUtility;
import haru.uwu.utils.render.engine2d.RenderUtility;
import haru.uwu.utils.render.font.Fonts;

import net.minecraft.client.Minecraft;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * SliderComponent
 */
public class SliderComponent extends Component {

    private final SliderSetting setting;

    public SliderComponent(SliderSetting setting) {
        this.setting = setting;
        this.setHeight(18);
    }
    private float newValue, lastValue;
    private float anim;
    private boolean drag;
    private boolean hovered = false;

    @Override
    public void render(MatrixStack stack, float mouseX, float mouseY) {
        super.render(stack, mouseX, mouseY);
        Fonts.sfbold.drawText(stack, setting.getName(), getX() + 5, getY() + 4.5f / 2f + 1, ColorUtility.rgb(153, 153, 153), 5.5f, 0.05f);
        Fonts.sfbold.drawText(stack, String.valueOf(setting.get()), getX() + getWidth() - 6 - Fonts.sfbold.getWidth(String.valueOf(setting.get()), 5.5f), getY() + 4.5f / 2f + 1, ColorUtility.rgb(153, 153, 153), 5.5f, 0.05f);

        RenderUtility.drawRoundedRect(getX() + 5, getY() + 12, getWidth() - 10, 2, 0.6f, ColorUtility.rgba(55,55,55,100));
        anim = MathUtility.fast(anim, (getWidth() - 10) * (setting.get() - setting.min) / (setting.max - setting.min), 20);
        float sliderWidth = anim;
        RenderUtility.drawRoundedRect(getX() + 5, getY() + 12, sliderWidth, 2, 1, ColorUtility.rgba(123, 123, 123,200));
        RenderUtility.drawCircle(getX() + 5 + sliderWidth, getY() + 13, 5, ColorUtility.rgba(153, 153, 153,255));
        //RenderUtility.drawShadowCircle(getX() + 5 + sliderWidth, getY() + 13, 10, Theme.rectColor);
        if (drag) {
            GLFW.glfwSetCursor(Minecraft.getInstance().getMainWindow().getHandle(),
                    GLFW.glfwCreateStandardCursor(GLFW.GLFW_HRESIZE_CURSOR));
            float newValue = (float) MathHelper.clamp(
                    MathUtility.round((mouseX - getX() - 5) / (getWidth() - 10) * (setting.max - setting.min) + setting.min,
                            setting.increment), setting.min, setting.max);
            if (newValue != lastValue) {
                setting.set(newValue);
                lastValue = newValue;
                SoundPlayer.playSound("guislidermove.wav");
            }
        }
        if (isHovered(mouseX, mouseY)) {
            if (MathUtility.isHovered(mouseX, mouseY, getX() + 5, getY() + 10, getWidth() - 10, 3)) {
                if (!hovered) {
                    GLFW.glfwSetCursor(Minecraft.getInstance().getMainWindow().getHandle(), Cursors.RESIZEH);
                    hovered = true;
                }
            } else {
                if (hovered) {
                    GLFW.glfwSetCursor(Minecraft.getInstance().getMainWindow().getHandle(), Cursors.ARROW);
                    hovered = false;
                }
            }
        }
    }

    @Override
    public void mouseClick(float mouseX, float mouseY, int mouse) {
        if (MathUtility.isHovered(mouseX, mouseY, getX() + 5, getY() + 10, getWidth() - 10, 3)) {
            drag = true;
        }
        super.mouseClick(mouseX, mouseY, mouse);
    }

    @Override
    public void mouseRelease(float mouseX, float mouseY, int mouse) {
        drag = false;
        super.mouseRelease(mouseX, mouseY, mouse);
    }

    @Override
    public boolean isVisible() {
        return setting.visible.get();
    }

}